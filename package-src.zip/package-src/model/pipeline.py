from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler
from sklearn.compose import ColumnTransformer
from catboost import CatBoostClassifier

from config.core import config

preprocessor = ColumnTransformer(
    transformers=[
        ("num", MinMaxScaler(), config.model_config.numeric_vars),
    ],
    remainder='passthrough'
)

# Pipeline completo con CatBoost
ventas_pipe = Pipeline(
    [
        ("preprocessor", preprocessor),
        ("CatBoost",
            CatBoostClassifier(
                random_seed=config.model_config.random_state,
                cat_features=config.model_config.categorical_vars_ind,
                verbose=0
            ),
        ),
    ]
)
